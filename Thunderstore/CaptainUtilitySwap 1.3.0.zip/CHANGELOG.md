## 1.3.0
- fixed stocks not being reset when a stage restarts
- improved swapping code

## 1.2.0
- fixed bugs in multiplayer
- fixed bugs all around

## 1.1.0
- Fixed a breaking bug that caused a lot of errors..

## 1.0.0
- First release