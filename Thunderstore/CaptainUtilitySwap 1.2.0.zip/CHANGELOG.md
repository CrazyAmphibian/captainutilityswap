## 1.1.0
- Fixed a breaking bug that caused a lot of errors..

## 1.0.0
- First release